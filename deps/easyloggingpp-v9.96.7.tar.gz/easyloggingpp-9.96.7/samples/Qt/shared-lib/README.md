```
 A very simple sample demonstrating an app and shared-lib usage that both uses
 easylogging++ as their logging library.

 @rev    1.0
 @since  v9.01
 @author mkhan3189
```
