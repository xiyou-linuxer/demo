People who have agreed to the
[Cesanta CLA](https://docs.cesanta.com/contributors_la.shtml)
can make contributions. Note that the CLA isn't a copyright
_assigment_ but rather a copyright _license_.
You retain the copyright on your contributions.

We follow the Google C/C++ style guide: https://google.github.io/styleguide/cppguide.html
We'd appreciate if your contribution follows the same style guide.
