---
title: "mg_mbuf_append_base64_putc()"
decl_name: "mg_mbuf_append_base64_putc"
symbol_kind: "func"
signature: |
  void mg_mbuf_append_base64_putc(char ch, void *user_data);
---

Use with cs_base64_init/update/finish in order to write out base64 in chunks. 

