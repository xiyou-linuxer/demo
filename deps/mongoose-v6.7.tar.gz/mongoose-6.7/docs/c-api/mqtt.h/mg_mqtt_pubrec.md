---
title: "mg_mqtt_pubrec()"
decl_name: "mg_mqtt_pubrec"
symbol_kind: "func"
signature: |
  void mg_mqtt_pubrec(struct mg_connection *nc, uint16_t message_id);
---

Sends a PUBREC command with a given `message_id`. 

